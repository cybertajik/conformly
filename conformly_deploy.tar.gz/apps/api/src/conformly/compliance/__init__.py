"""Compliance workspace package."""
