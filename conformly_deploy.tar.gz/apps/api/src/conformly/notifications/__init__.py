"""Deterministic notification delivery infrastructure."""
