"""Standards-based authentication boundary."""
