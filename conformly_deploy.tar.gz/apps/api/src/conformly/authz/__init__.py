"""Centralized capability-based authorization."""
